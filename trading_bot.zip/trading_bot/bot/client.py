from binance.client import Client
import os

API_KEY = "hQJGb54e0zfl5VU2CWc6QwiHWVfDPD2iFE0TuriwWHF2aRszSajQwaOAkPxzaIZH"
API_SECRET = "36Mp5EmkYxla2yU0csyqwmcrRWRVNt8HGFVfo9kix9DNZ5P1eNfrAr1LWuHmZj34"

def get_client():
    client = Client(API_KEY, API_SECRET)
    client.FUTURES_URL = "https://testnet.binancefuture.com/fapi"
    return client
