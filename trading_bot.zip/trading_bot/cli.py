import logging
from bot.client import get_client
from bot.orders import place_order
from bot.validators import validate_side, validate_type
from bot.logging_config import setup_logging

def main():
    setup_logging()

    symbol = input("Enter Symbol (e.g., BTCUSDT): ").upper()
    side = input("Enter Side (BUY/SELL): ").upper()
    order_type = input("Enter Type (MARKET/LIMIT): ").upper()
    quantity = input("Enter Quantity: ")

    price = None
    if order_type == "LIMIT":
        price = input("Enter Price: ")

    try:
        validate_side(side)
        validate_type(order_type)

        client = get_client()

        order = place_order(
            client,
            symbol,
            side,
            order_type,
            quantity,
            price
        )

        print("\nOrder Request Summary:")
        print(f"Symbol: {symbol}")
        print(f"Side: {side}")
        print(f"Type: {order_type}")

        print("\nOrder Response:")
        print(f"Order ID: {order['orderId']}")
        print(f"Status: {order['status']}")
        print(f"Executed Qty: {order['executedQty']}")

        print("\nSUCCESS!")

    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
